//╔═════════════════════════════════════════════════════════════════════════════════╗
//║                                                                                 ║
//║   ╔╗      ╔╗   ╔╗╔╗╔╗╔╗╔╗   ╔╗╔╗╔╗╔╗     ╔╗      ╔╗   ╔╗╔╗╔╗╔╗╔╗   ╔╗           ║
//║   ╚╝    ╔╗╚╝   ╚╝╚╝╚╝╚╝╚╝   ╚╝╚╝╚╝╚╝╔╗   ╚╝╔╗    ╚╝   ╚╝╚╝╚╝╚╝╚╝   ╚╝           ║
//║   ╔╗  ╔╗╚╝     ╔╗           ╔╗      ╚╝   ╔╗╚╝    ╔╗   ╔╗           ╔╗           ║
//║   ╚╝╔╗╚╝       ╚╝╔╗╔╗╔╗╔╗   ╚╝╔╗╔╗╔╗     ╚╝  ╔╗  ╚╝   ╚╝╔╗╔╗╔╗╔╗   ╚╝           ║
//║   ╔╗╚╝╔╗       ╔╗╚╝╚╝╚╝╚╝   ╔╗╚╝╚╝╚╝╔╗   ╔╗  ╚╝  ╔╗   ╔╗╚╝╚╝╚╝╚╝   ╔╗           ║
//║   ╚╝  ╚╝╔╗     ╚╝           ╚╝      ╚╝   ╚╝    ╔╗╚╝   ╚╝           ╚╝           ║
//║   ╔╗    ╚╝╔╗   ╔╗╔╗╔╗╔╗╔╗   ╔╗      ╔╗   ╔╗    ╚╝╔╗   ╔╗╔╗╔╗╔╗╔╗   ╔╗╔╗╔╗╔╗╔╗   ║
//║   ╚╝      ╚╝   ╚╝╚╝╚╝╚╝╚╝   ╚╝      ╚╝   ╚╝      ╚╝   ╚╝╚╝╚╝╚╝╚╝   ╚╝╚╝╚╝╚╝╚╝   ║
//║                                                                                 ║
//║   This file is a part of the project Judge Sharp done by Ahmad Bashar Eter.     ║
//║   This program is free software: you can redistribute it and/or modify          ║
//║   it under the terms of the GNU General Public License version 3.               ║
//║   This program is distributed in the hope that it will be useful, but WITHOUT   ║
//║   ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS ║
//║   FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details ║
//║   GNU General Public: http://www.gnu.org/licenses.                              ║
//║   For usage not under GPL please request my approval for commercial license.    ║
//║   Copyright(C) 2017 Ahmad Bashar Eter.                                          ║
//║   KernelGD@Hotmail.com                                                          ║
//║                                                                                 ║
//╚═════════════════════════════════════════════════════════════════════════════════╝

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JudgeSharp.Core
{
    /// <summary>
    ///NOTE: THIS CLASS NOT YET IMPLEMENTED!
    ///TODO: Implemented this class to handle problems that cant be tested with output equality (e.g.: multiple 
    ///      valid output problems), you can use the idea of tester code and generator code.
    ///      As if you implement the functionality to receive a code and compile it which will be executed to determine if
    ///      the output of the solution is correct. This code will named as tester code and it will remain visible to the public.
    ///      and you will implement the functionality to receive another code and compile it which can be executed to determine the 
    ///      actual correct output. This code must be encrypted as it is the solution for the problem.
    ///      However the encryption must be done by a password which is hashed, encrypted, and stored.
    ///      for the password encryption you can't encrypt it by the correct output because there multiple valid output,
    ///      in this case you can make the tester to output something and as the output is checked you will build up your password.
    /// </summary> 
    public class TesterAndGeneratorProblem : ProblemSpecification
    {
        public override string[] GetCorrectOutput(string password)
        {
            throw new NotImplementedException();
        }

        public override string GetPassword(string[] correctOutput)
        {
            throw new NotImplementedException();
        }

        public override bool IsCorrect(string output, int index)
        {
            throw new NotImplementedException();
        }

        public override bool Load(Stream stream)
        {
            throw new NotImplementedException();
        }

        public override bool Save(Stream stream)
        {
            throw new NotImplementedException();
        }
    }
}
